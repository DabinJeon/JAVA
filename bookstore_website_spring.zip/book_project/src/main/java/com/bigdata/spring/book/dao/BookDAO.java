package com.bigdata.spring.book.dao;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.inject.Inject;

import org.apache.ibatis.session.SqlSession;
import org.springframework.stereotype.Repository;
import com.bigdata.spring.book.vo.BookVO;

@Repository
public class BookDAO implements BookDAOImpl {
	
	@Inject
	SqlSession sqlSession;
	//	SqlSession sqlSession =new SqlSession();
	
	@Override
	public List<BookVO> bookList() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList");
		return blist;
	}
	@Override
	public List<BookVO> bookList_1() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList_1");
		return blist;
	}
	@Override
	public List<BookVO> bookList_2() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList_2");
		return blist;
	}
	@Override
	public List<BookVO> bookList_3() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList_3");
		return blist;
	}
	@Override
	public List<BookVO> bookList_4() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList_4");
		return blist;
	}
	@Override
	public List<BookVO> bookList_0() {
		// TODO Auto-generated method stub
		List<BookVO> blist = sqlSession.selectList("book.bookList_0");
		return blist;
	}

	@Override
	public void insertBook(BookVO bvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BookVO viewBook(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBook(String no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBook(BookVO bvo) {
		// TODO Auto-generated method stub
		
	}

}
