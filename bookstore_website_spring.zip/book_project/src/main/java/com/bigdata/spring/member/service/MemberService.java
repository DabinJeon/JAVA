package com.bigdata.spring.member.service;

import java.util.List;

import javax.inject.Inject;

import org.springframework.stereotype.Service;

import com.bigdata.spring.member.dao.MemberDAOImpl;
import com.bigdata.spring.member.vo.MemberVO;

@Service
public class MemberService implements MemberServiceImpl{

	@Inject
	MemberDAOImpl memberDao;
	
	
	@Override
	public List<MemberVO> memberList() {
		// TODO Auto-generated method stub
		return memberDao.memberList();
	}

	@Override
	public void insertMember(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public MemberVO viewMember(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteMember(String no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updaeMember(MemberVO mvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public String checkIdPwd(String id, String pwd) {
		return memberDao.checkIdPwd(id, pwd);
	}
	
	@Override
	   public int registerMember(MemberVO rvo) {
	   return memberDao.memberRegister(rvo);	
	}

}
