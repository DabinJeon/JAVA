package com.bigdata.spring.member.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bigdata.spring.member.service.MemberServiceImpl;
import com.bigdata.spring.member.vo.MemberVO;

@Controller
@RequestMapping("member/*")
public class MemberController {

	@Inject
	MemberServiceImpl memberService; 
	
	@RequestMapping(value="memberlist.do", method=RequestMethod.GET)
	public String memberlist(Model model) {
		
		model.addAttribute("mlist", memberService.memberList());
		return "member/member_list";
	}
	
	@RequestMapping("login.do")
	public String login() {
		return "member/login";
	}
	
	@RequestMapping("memberJoin.do")
	public String join() {
		return "member/join";
	}
	
	@RequestMapping("login_check.do")
	public ModelAndView login_check(@RequestParam String id, 
												String pwd,
										HttpSession session,
										ModelAndView mav) {
		System.out.println("id : "+id);
		System.out.println("pwd : "+pwd);
		String loginID = memberService.checkIdPwd(id, pwd);
		if(loginID !=null) {
			session.setAttribute("id", loginID);
		}
		if(loginID!= null) {
			mav.setViewName("home");
			//이동할 경로를 적어줌
		}else {
			mav.setViewName("member/login");
			mav.addObject("msg","error");
			//넘길 값을 넣어줌(key, value)
		}
		return mav;
	}
	
	@RequestMapping("logout.do")
	public ModelAndView logout(HttpSession session, ModelAndView mav) {
		session.invalidate();
		mav.setViewName("member/login");
		mav.addObject("msg","logout");
		return mav;
	}

	@RequestMapping("register.do")
	public String resgister() {
	   return "member/register";
	}

	@RequestMapping("memberRegister.do")
	public ModelAndView memberRegister(@RequestParam String id,String pwd,String name,String address, String phone_number,int age, String admin_yn,
			HttpSession session, ModelAndView mav) {
		
	   MemberVO rvo = new MemberVO();
	   rvo.setId(id);
	   rvo.setPwd(pwd);
	   rvo.setName(name);
	   rvo.setAddress(address);
	   rvo.setPhone_number(phone_number);
	   rvo.setAge(age);
	   rvo.setAdmin_yn(admin_yn);

	   int registerChcek = memberService.registerMember(rvo);
	   if(registerChcek != 1) {
	      mav.setViewName("member/register");
	      mav.addObject("msg","error");
	   }else {
	      mav.setViewName("member/login");
	      mav.addObject("msg","register");
	   }
	     return mav;
	}
}
