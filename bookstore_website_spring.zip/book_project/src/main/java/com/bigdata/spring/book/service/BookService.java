package com.bigdata.spring.book.service;

import java.util.List;
import javax.inject.Inject;
import org.springframework.stereotype.Service;

import com.bigdata.spring.book.dao.BookDAO;
import com.bigdata.spring.book.dao.BookDAOImpl;
import com.bigdata.spring.book.vo.BookVO;

@Service
public class BookService implements BookServiceImpl{

	@Inject
	BookDAOImpl bookDao;
	
	
	@Override
	public List<BookVO> bookList() {
		// TODO Auto-generated method stub
		return bookDao.bookList();
	}
	@Override
	public List<BookVO> bookList_1() {
		// TODO Auto-generated method stub
		return bookDao.bookList_1();
	}
	@Override
	public List<BookVO> bookList_2() {
		// TODO Auto-generated method stub
		return bookDao.bookList_2();
	}
	@Override
	public List<BookVO> bookList_3() {
		// TODO Auto-generated method stub
		return bookDao.bookList_3();
	}
	@Override
	public List<BookVO> bookList_4() {
		// TODO Auto-generated method stub
		return bookDao.bookList_4();
	}
	@Override
	public List<BookVO> bookList_0() {
		// TODO Auto-generated method stub
		return bookDao.bookList_0();
	}

	@Override
	public void insertBook(BookVO bvo) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public BookVO viewBook(String name) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public void deleteBook(String no) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void updateBook(BookVO bvo) {
		// TODO Auto-generated method stub
		
	}

}