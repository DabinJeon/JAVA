package com.bigdata.spring.book.controller;

import javax.inject.Inject;
import javax.servlet.http.HttpSession;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.bigdata.spring.book.service.BookServiceImpl;

@Controller
@RequestMapping("book/*")
public class BookController {

	@Inject
	BookServiceImpl bookService; 
	
	@RequestMapping(value="booklist.do", method=RequestMethod.GET)
	public String booklist(Model model) {
		
		model.addAttribute("blist", bookService.bookList());
		return "book/book_list";
	}
	
	@RequestMapping(value="booklist_1.do", method=RequestMethod.GET)
	public String booklist_1(Model model) {
		
		model.addAttribute("blist_1", bookService.bookList_1());
		return "book/book_list_1";
	}
	
	@RequestMapping(value="booklist_2.do", method=RequestMethod.GET)
	public String booklist_2(Model model) {
		
		model.addAttribute("blist_2", bookService.bookList_2());
		return "book/book_list_2";
	}
	
	@RequestMapping(value="booklist_3.do", method=RequestMethod.GET)
	public String booklist_3(Model model) {
		
		model.addAttribute("blist_3", bookService.bookList_3());
		return "book/book_list_3";
	}
	
	@RequestMapping(value="booklist_4.do", method=RequestMethod.GET)
	public String booklist_4(Model model) {
		
		model.addAttribute("blist_4", bookService.bookList_4());
		return "book/book_list_4";
	}
	@RequestMapping(value="booklist_0.do", method=RequestMethod.GET)
	public String booklist_0(Model model) {
		
		model.addAttribute("blist_0", bookService.bookList_0());
		return "book/book_list_0";
	}
}