package com.bigdata.spring.book.dao;

import java.util.List;
import com.bigdata.spring.book.vo.BookVO;

public interface BookDAOImpl {
	public List<BookVO> bookList();
	public List<BookVO> bookList_1();
	public List<BookVO> bookList_2();
	public List<BookVO> bookList_3();
	public List<BookVO> bookList_4();
	public List<BookVO> bookList_0();
	public void insertBook(BookVO bvo);
	public BookVO viewBook(String name);
	public void deleteBook(String no);
	public void updateBook(BookVO bvo);
}