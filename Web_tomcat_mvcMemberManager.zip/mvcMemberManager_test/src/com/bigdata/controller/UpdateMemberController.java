package com.bigdata.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.bigdata.service.Web_memberService;
import com.bigdata.service.Web_memberServiceImpl;
import com.bigdata.vo.Web_memberVO;

/**
 * Servlet implementation class UpdateMemberController
 */
//@WebServlet("/UpdateMemberController")
public class UpdateMemberController extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMemberController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		 System.out.println("called doGet");
		
		 resp.setContentType("text/html; charset=UTF-8");  // 한글 깨짐 방지
		 req.setCharacterEncoding("UTF-8");
	     int no = Integer.parseInt(req.getParameter("no"));
	     String id = req.getParameter("id");
	     String pwd = req.getParameter("pwd");
	     String name = req.getParameter("name");
	     String addr = req.getParameter("addr");
	     String ph_number = req.getParameter("ph_number");
	     int age = Integer.parseInt(req.getParameter("age"));
	     String admin_yn = req.getParameter("admin_yn");
	     Web_memberVO wmvo = new Web_memberVO();
	     wmvo.setNo(no);
	     wmvo.setId(id);
	     wmvo.setPwd(pwd);
	     wmvo.setName(name);
	     wmvo.setAddress(addr);
	     wmvo.setPhone_number(ph_number);
	     wmvo.setAge(age);
	     wmvo.setAdmin_yn(admin_yn);
	     Web_memberServiceImpl service = new Web_memberService();

	     int result = service.update_Web_member(wmvo);
	     String path="";
	     if(result==0) {
	         path="updateMember.jsp";
	         req.setAttribute("wmvo", wmvo);
	     }else {
	         path="Menu.jsp";
	     }
	      
	      
	      RequestDispatcher rd = req.getRequestDispatcher(path);
	      rd.forward(req, resp);
	      
	   }

	   protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	      doGet(request, response);
	   }

	}