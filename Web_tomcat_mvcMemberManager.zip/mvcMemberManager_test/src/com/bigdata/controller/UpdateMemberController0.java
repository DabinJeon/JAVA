package com.bigdata.controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.util.*;

import com.bigdata.dao.Web_memberDAO;
import com.bigdata.vo.Web_memberVO;
import com.bigdata.service.Web_memberService;
import com.bigdata.service.Web_memberServiceImpl;
/**
 * Servlet implementation class UpdateMemberController0
 */
//@WebServlet("/UpdateMember0")
public class UpdateMemberController0 extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public UpdateMemberController0() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		 String no  = req.getParameter("no");
	     Web_memberServiceImpl service = new Web_memberService();
	     Web_memberVO wmvo = new Web_memberVO();
	     wmvo.setNo(Integer.parseInt(no));
	      
	     wmvo = service.selectWeb_member(wmvo.getNo());
	     String path = "updateList.jsp";
	      
	     req.setAttribute("wmvo", wmvo);
	     RequestDispatcher rd = req.getRequestDispatcher(path);
	     rd.forward(req, resp);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
